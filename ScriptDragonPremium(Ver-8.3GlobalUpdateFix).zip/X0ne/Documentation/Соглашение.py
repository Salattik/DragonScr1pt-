import time
import sys
import os
import subprocess
from termcolor import colored

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

def execute_python_file(file_path):
    subprocess.run(['python', file_path])

print(colored("--------------------------//", 'cyan'))
print(colored("Соглашение!", 'green'))
print(colored("\nДанная программа создана в ознакомительных целях, все действия вы делаете на свой страх и риск!", 'green'))
print(colored("\nРазработчик не несет никакой ответсвенности за последствия использования данной программы, не следует ее применять в разных конфликтах.", 'green'))
print(colored("\nИспользуйте данную программу с осторожностью, и уважайте личное мнение и пространство других людей.", 'green'))
print(colored("\nИспользование данной программы может нести серьезные проблемы с законом, то не следует использовать эту программу для вреда устройства другого человека.", 'green'))

def wait_for_enter():
    print(colored("\nНажмите кнопку Enter для принятия соглашения...", 'yellow'))
    input()

if __name__ == "__main__":
    wait_for_enter()
    execute_python_file("/storage/emulated/0/Documents/X0ne/logs/Loading.py")