import pyautogui
import os
import time 
import subprocess
from termcolor import colored

def execute_python_file(file_path):
    subprocess.run(['python', file_path])

def SendMessage():
    message = input(colored("Введите сообщение: ", 'green'))
    amount = 600000000
    time.sleep(6)
    
    for i in range(amount):
        amount -=1
        
        pyautogui.typewrite(message.strip())
        pyautogui.press('enter')
        
SendMessage()

En = input(colored("\nНажмите Enter для перезапуска...", 'yellow'))

if En == '':
    execute_python_file("/storage/emulated/0/Documents/X0ne/logs/llib.py")