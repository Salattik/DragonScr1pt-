cd
rm -rf Spavveri
git clone https://github.com/Hironotori/Spavveri
cd
rm -rf Spavveri
git clone https://github.com/Hironotori/Spavveri
cd
cd Spavveri
python3 Spavveri.py
