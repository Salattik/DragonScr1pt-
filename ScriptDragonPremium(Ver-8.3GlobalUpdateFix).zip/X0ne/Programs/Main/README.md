# Spavveri

![Скриншот 25 01 22_21 46 50](https://user-images.githubusercontent.com/81866681/151057665-a5a9f411-2966-4fea-b79b-956a921ebfee.png)

<b>Hey!</b>
This is a small sms bomber, the number of<br/>
sms sent per second depends on the speed<br/>
of your internet. If you use this bomber<br/>
at the same time  by several people, you<br/>
can easily put the phone!

<b>Valid only for Ukraine numbers!</b>

# NEWS

</b>https://t.me/Bomberukr</b>

# UPDATE

<br/>To update write<br/>
<b>bash update.sh<b>

# Install Kali linux

<br/>sudo apt install python3<br/>
<br/>sudo apt install python3-pip<br/>
<br/>sudo apt install git<br/>
<br/>cd<br/>
<br/>git clone https://github.com/Hironotori/Spavveri<br/>
<br/>cd Spavveri<br/>
python3 Spavveri.py

# Install Termux

УСТАНАВЛИВАТЬ ПРОЛОЖЕНИЯ ТЕРМУКС ЖДЕСЬ:https://f-droid.org/repo/com.termux_117.apk

<b>apt update<b>    (ОДИН РАЗ)

apt upgrade   (ОДИН РАЗ)

apt install python   (ОДИН РАЗ)

apt install python2  (ОДИН РАЗ)

apt install git      (ОДИН РАЗ)

cd                   (КАЖДИЙ РАЗ)

git clone https://github.com/Hironotori/Spavveri     (ОДИН РАЗ)

cd Spavveri                         (КАЖДИЙ РАЗ)

pip install -r requirements.txt     (ОДИН РАЗ)

python3 Spavveri.py                 (КАЖДИЙ РАЗ)
