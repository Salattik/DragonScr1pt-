from termcolor import colored
import os
import sys
import time
import subprocess
import urllib.parse

def execute_python_file(file_path):
    subprocess.run(['python', file_path])

def print_show(text, delay=0.04):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def loading_animation(duration, bar_length=20, fill_char='█'):
    start_time = time.time()

    while time.time() - start_time < duration:
        percent = min(100, int((time.time() - start_time) / duration * 100))
        filled_length = int(bar_length * percent / 100)
        bar = fill_char * filled_length + '-' * (bar_length - filled_length)

        sys.stdout.write("\r[{}] {}%".format(bar, percent))
        sys.stdout.flush()
        time.sleep(duration / (bar_length * 2))

    print(colored("\nLoading complete!", 'yellow'))

def mask_link(original_link, service):
    # Кодируем оригинальную ссылку для добавления в параметры запроса
    encoded_original_link = urllib.parse.quote(original_link, safe='')

    # Генерируем маскированную ссылку
    if service.lower() == "discord":
        masked_link = f"https://discord.com/redirect?url={encoded_original_link}"
    elif service.lower() == "google":
        masked_link = f"https://www.google.com/url?q={encoded_original_link}"
    elif service.lower() == "youtube":
        masked_link = f"https://www.youtube.com/redirect?q={encoded_original_link}"
    else:
        masked_link = original_link
    
    return masked_link

print("«---------------------------»")
# Получаем оригинальную ссылку и выбор сервиса от пользователя
original_link = input(colored("Введите оригинальную ссылку: ", 'green'))

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

service = input(colored("Выберите сервис для маскирования (discord, google, youtube): ", 'yellow'))

# Маскируем ссылку
masked_link = mask_link(original_link, service)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

loading_animation_duration = 1  # Укажите желаемую длительность анимации в секундах
loading_animation(loading_animation_duration, bar_length=25)
# Выводим результат
print("«-----------------------------------»")

print(colored("Ваша ссылка готова:", 'green'), end=' ')
for char in masked_link:
    print(colored(char, 'red'), end='', flush=True)
    time.sleep(0.04)  # Задержка в 0.1 секунды между выводом символов
print()  # Для перехода на новую строку после анимации

En = input(colored("\nНажмите Enter для перезапуска...", 'yellow'))

if En == '':
    execute_python_file("/storage/emulated/0/Documents/X0ne/logs/llib.py")