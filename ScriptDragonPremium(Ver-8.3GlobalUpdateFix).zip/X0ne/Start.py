import os
import subprocess
from termcolor import colored

def execute_python_file(file_path):
    subprocess.run(['python', file_path])

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

print(colored("Вы хотите посетить наш телеграм канал?", 'cyan'))
print("«------------------»")
print(colored("»", 'yellow') + colored("[", 'cyan') + colored("1", 'green') + colored("] Да", 'cyan'))
print(colored("»", 'yellow') + colored("[", 'cyan') + colored("2", 'green') + colored("] Нет", 'cyan'))
print("«------------------»")
#------------------------------------------------------------
try:
    Vp = input(colored("Введите/> ", 'green'))
    if Vp not in ['1', '2']:
        raise ValueError(colored("Не корректно указан ответ!", 'red'))
except ValueError as e:
    print(e)
    exit()
    
if Vp == '1':
    os.system('termux-open-url https://t.me/DragonScrip')  
    execute_python_file("/storage/emulated/0/Documents/X0ne/documentation/Соглашение.py")
    def clear_console():
        os.system('cls' if os.name == 'nt' else 'clear')
    clear_console()
if Vp == '2': 
    execute_python_file("/storage/emulated/0/Documents/X0ne/documentation/Соглашение.py")
    def clear_console():
        os.system('cls' if os.name == 'nt' else 'clear')
    clear_console()