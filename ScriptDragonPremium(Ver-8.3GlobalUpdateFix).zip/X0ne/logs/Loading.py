import os
import sys
import subprocess
import time
from termcolor import colored

def execute_python_file(file_path):
    subprocess.run(['python', file_path])

def print_slowly(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.030)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

clear_console()

time.sleep(0.50)

print("«------------------»")
text_to_print = "Выполняется загрузка файлов..."
color = colored(text_to_print, 'green')
print_slowly(color)
time.sleep(3)

text_to_print = "\nЗагрузка атрибутов..."
color = colored(text_to_print, 'green')
print_slowly(color)
time.sleep(1)

text_to_print = "\nВыполняется компиляция библиотек..."
color = colored(text_to_print, 'green')
print_slowly(color)
time.sleep(2.50)

text_to_print = "\nЗапуск..."
color = colored(text_to_print, 'green')
print_slowly(color)
time.sleep(0.01)
execute_python_file("/storage/emulated/0/Documents/X0ne/Programs/llib.py")